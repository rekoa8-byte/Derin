// Service Worker: fast repeat visits + resilience on slow / unstable home lines (FTTH) and mobile data.
// v3: purges caches from older versions (they could hold a broken copy of a script) and never stores HTML as an asset.
const CACHE_NAME = 'arishop-offline-v3';
const PRECACHE_ASSETS = [
  '/',
  '/index.html',
  '/manifest.json',
  '/derin-logo.svg',
  '/vendor/fa/fa.css',
  '/vendor/fa/webfonts/fa-solid-900.woff2'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) =>
      // Each file is added on its own so one failure cannot block the whole install
      Promise.all(PRECACHE_ASSETS.map((u) => cache.add(u).catch(() => {})))
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.map((key) => (key !== CACHE_NAME ? caches.delete(key) : null))))
      .then(() => self.clients.claim())
  );
});

// A response is only worth caching when it is a real, successful same-origin file of the expected kind.
function isCacheableAsset(req, res) {
  if (!res || res.status !== 200 || res.type !== 'basic') return false;
  const ct = (res.headers.get('content-type') || '').toLowerCase();
  // The SPA fallback returns index.html for missing files; storing that as a .js/.css file would break the app.
  if (ct.includes('text/html') && req.destination !== 'document') return false;
  return true;
}

self.addEventListener('fetch', (event) => {
  const req = event.request;
  const url = new URL(req.url);

  if (req.method !== 'GET' || !url.protocol.startsWith('http')) return;
  // Only manage our own files. Firestore, fonts CDN, images from other hosts etc. go straight to the network.
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/')) return;

  // Opening the site: network first (3.5s), then the saved copy so the store still opens on a weak line.
  if (req.mode === 'navigate') {
    event.respondWith((async () => {
      try {
        const timeout = new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 3500));
        const response = await Promise.race([fetch(req), timeout]);
        if (response && response.status === 200) {
          const copy = response.clone();
          caches.open(CACHE_NAME).then((c) => c.put('/index.html', copy)).catch(() => {});
          return response;
        }
      } catch (_) { /* slow or offline: fall through to cache */ }
      const cached = (await caches.match('/index.html')) || (await caches.match('/'));
      if (cached) return cached;
      return fetch(req);
    })());
    return;
  }

  // Everything else: serve the saved copy immediately, refresh it in the background.
  event.respondWith(
    caches.match(req).then((cached) => {
      const network = fetch(req).then((res) => {
        if (isCacheableAsset(req, res)) {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy)).catch(() => {});
        }
        return res;
      }).catch(() => cached);
      return cached || network;
    })
  );
});
